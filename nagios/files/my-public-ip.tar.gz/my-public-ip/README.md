# my-public-ip
Bash script to get the public IP using several web server (ipinfo.io, myip.net, shtuff.it, monip.org)
