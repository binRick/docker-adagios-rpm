#!/bin/bash
cd $( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
export IP=""

source functions.sh

for cm in $ALL
do
	$cm
	echo -e "$IP"
	[[ -n "$IP" ]] && exit
done
