user_pref("network.negotiate-auth.trusted-uris", ".test.local");
user_pref("browser.startup.homepage", "http://omd.test.local/demo/thruk/");
user_pref("browser.shell.checkDefaultBrowser", "false");
user_pref("general.warnOnAboutConfig", "false");
