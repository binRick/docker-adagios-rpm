<?php 

// sort order for the different states, bigger will come first
$sort_order_status = Array();
$sort_order_status["DOWN"] = 1;
$sort_order_status["UNRECHABLE"] = 2;
$sort_order_status["CRITICAL"] = 3;
$sort_order_status["WARNING"] = 4;
$sort_order_status["UNKNOWN"] = 5;

?>