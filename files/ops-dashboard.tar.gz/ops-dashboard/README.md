Ops-dashboard
=============

See the project homepage at <http://bdeak.github.io/ops-dashboard/>

The documentation can be found in the [Wiki](https://github.com/bdeak/ops-dashboard/wiki)
