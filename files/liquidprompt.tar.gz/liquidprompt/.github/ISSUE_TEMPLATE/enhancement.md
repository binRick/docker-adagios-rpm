---
name: Feature request
about: Suggest an idea for Liquidprompt
title: ''
labels: 'enhancement'
assignees: ''

---
<!--- Provide a general summary of the issue in the title above -->
<!--- This is only a template, feel free to expand -->

### Description
<!--- Tell us what should happen -->

### How will this be useful?
<!--- Tell/show us how this feature will be used -->

### Example prompt
<!--- Show us what a prompt with this feature enabled would look like -->

